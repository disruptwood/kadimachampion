export const baseURL = 'https://shalom.kruzhok.io';
